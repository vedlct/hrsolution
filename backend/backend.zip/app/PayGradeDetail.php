<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PayGradeDetail extends Model
{
    protected $table = "paygradedetail";
    protected $primaryKey='id';
    public $timestamps = false;
}
