<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaySalarySheetMain extends Model
{
    protected $table = "paysalarysheetmain";
    protected $primaryKey='id';
    public $timestamps = false;
}
