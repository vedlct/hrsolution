<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class religion extends Model
{
    protected  $table ='religions';
    protected $primaryKey='id';
}
