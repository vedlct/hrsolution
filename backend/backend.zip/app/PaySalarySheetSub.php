<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaySalarySheetSub extends Model
{
    protected $table = "paysalarysheetsub";
    protected $primaryKey='id';
    public $timestamps = false;
}
