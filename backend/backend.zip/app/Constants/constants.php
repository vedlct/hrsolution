<?php

define('LEAVE_CATEGORY',array(
    "Casual"=>'cs',
    "Sick"=>'sick',
//    "Offday"=>'off',
    "NoShift"=>'noShi',
    "Marriage"=>'marri',
    "Leave with out pay"=>'LWP',
    "Team Leave"=>'TL',

));










