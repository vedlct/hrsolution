<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PayGradeParent extends Model
{
    protected $table = "paygradeparent";
    protected $primaryKey='id';
    public $timestamps = false;
}
